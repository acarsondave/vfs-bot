data = {
    "email": "dj002@yopmail.com",
    "password": "Azerty2017@@",
    "bot_ids": ["2072675358"],            # separate with commas (,) for multiple chat ids
    "bot_token": "2056728617:AAFV4zIzbpX2YD9lCOpiCoYTanRSn6lF6qw",
    "custom_message": "Appointment is available.",
    "anticaptcha_key": "2c7a73e43189319a2706f5a8e876de06",
    "time_interval": 5,        # set the time to repeat appointment checks.
    "is_testing": False        # set True or False to toggle mode
}
