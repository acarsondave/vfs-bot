data = {
    "email": "dj002@yopmail.com",
    "password": "Azerty2017@@",
    "bot_ids": ["1152745173"],            # separate with commas (,) for multiple chat ids
    "bot_token": "2066490962:AAFZEmj4FoNDu7xtokzEWWncqFhxuh5YP0k",
    "custom_message": "Appointment is available.",
    "anticaptcha_key": "2c7a73e43189319a2706f5a8e876de06",
    "time_interval": 5,        # set the time to repeat appointment checks.
    "is_testing": False        # set True or False to toggle mode
}
